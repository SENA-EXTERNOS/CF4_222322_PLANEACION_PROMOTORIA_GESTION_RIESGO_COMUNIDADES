function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5oXPQM1dxKw":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

